/*
 * Alex Tarng
 * 8/19/14
 * Period 6
 * 
 * This was the second time doing this assignment, so I added less features than I did the first time.
 * It only has spots and a rough body, no facial features, tail, etc.
 */

public class Main
{
	
	public static void main(String[] args)
	{
		//Create new CowFrame and initialize it
		CowFrame c = new CowFrame();
		c.setDefaultCloseOperation(c.EXIT_ON_CLOSE);
		c.setVisible(true);
	}
}
